
#include<stdio.h> 
#include<stdlib.h> 
#include<string.h>
using namespace std;

int no = 651000145;
FILE* file=fopen("bankdata.txt","a+");
	
void storedata(FILE* file);

						/****************************************************************/

/*     section related to data storage        */



int acc_fun()
{
	no=no+10000;
	printf("\nACC. No- %d is allocated to you\n",no);
	return no;
}




struct account														// structure to store information of acc. holder
{
	
	int acc_no;
	int pass;
	int bal;
	char name[30];
	account* next;
};
account* bank=NULL;

struct account* open_acc(int pass,int bal,char name[])
{
	account* acc=(account*)malloc(sizeof(struct account));
	acc->acc_no=acc_fun();
	acc->pass=pass;
	acc->bal=bal;
	strcpy(acc->name,name);
	acc->next=NULL;
	//
	//
	return acc;
	
}

struct account* printacc(account* holder,int acc,int pass)
{
	if(holder==NULL)
	{
		printf("Wrong credential!!!!\n Account not FOUND\n");
		return NULL;
	}
	else if(holder->acc_no==acc)
	{
		if(holder->pass==pass)
		{
			printf("\nAccount Holder- %s\nAccount No- %d\nAccount Balance- %.2d\n",holder->name,holder->acc_no,holder->bal);
			int n;
			printf("\nENTER 1) TO CONTINUE\n");
			scanf("%d",&n);
			
			return holder;
		}
		else
		{
			printf("Wrong Password");
			return NULL;
		}
	}
	else
	return printacc(holder->next,acc,pass);
	
}


void insert(account **holder,int pass,int bal,char name[])
{
	if((*holder)==NULL)
	{
		*holder=open_acc(pass,bal,name);
		printacc(*holder,(*holder)->acc_no,pass);
		printf("\n\t\t\tThanks for Banking :)\n");
		
	}
	else
	 {
	 insert(&((*holder)->next),pass,bal,name);
	 
	}
}
void deletion(account** holder,int acc)
{
	if((*holder)==NULL)
		{
			printf("INVALID CREDITS\n");
			return;
		}
	if((*holder)->acc_no==acc)
	{
		account* temp=(*holder);
		(*holder)=(*holder)->next;
	//	printf("%d",temp->acc_no);
		printf("\n\t\t%d ACCOUNT HAS BEEN SUCCESSFULLY CLOSED !!!\n\t\tTHANKs %s -  YOU CAN TAKE YOUR REMAINING BALANCE %d\n",temp->acc_no,temp->name,temp->bal);
		delete(temp);
		
	}
	else
	deletion(&((*holder)->next),acc);
	
}





						 /*********************************************************/


/*          section related to display                     */

void options(account*);

void startnote()
{

	
	puts("\n\n\t\t\t* * * * * * * * * * * * * * * * * * * * * * * * * \n"
		"\t\t\t*                                               *\n"
		"\t\t\t*                                               *\n"
		"\t\t\t*      WELCOME TO AUTOMATIC BANKING SYSTEM      *\n"
		"\t\t\t*                                               *\n"
		"\t\t\t*                                               *\n"
		"\t\t\t* * * * * * * * * * * * * * * * * * * * * * * * *\n\n"
		"\t* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
	
}

void startingenterchoice();
void user(account** holds)
{
	startnote();
	startingenterchoice();
	int n;
	puts("\n\t\t 1) Existing User       2)New user  \n\t\t 3)EXIT");
	scanf("%d",&n);
	system("cls");
	startnote();
	if(n==1)
	{
		int check;
		int pass;
		system("cls");
		startnote();
		printf("\nENTER YOUR ACCOUNT NO. USER\n");
		scanf("%d",&check);
		printf("\nENTER YOUR PASSWORD  NO. USER\n");
		scanf("%d",&pass);
		
		account* change=printacc(*holds,check,pass);
		if(change!=NULL)
			options(change);
			
		
		
	}
	else if(n==2)
	{
		int balan,pas;
		char nm[100],nm1[100];
		printf("\nENTER YOUR FIRST NAME\n");
		scanf("%s",nm);
		printf("\nENTER YOUR SECOND NAME\n");
		scanf("%s",nm1);
		strcat(nm," ");
		strcat(nm,nm1);
		printf("\nENTER THE AMOUNT WITH YOU WANT TO OPEN \n");
		
		scanf("%d",&balan);
		
		printf("Enter the password (ONLY NUMBERS - 0001 ,...)\n");
		scanf("%d",&pas);
		
		insert(&bank,pas,balan,nm);
	}
	else
	{
	system("cls");
	printf("\n\n\t\t\tThanks Visit Again\n");
	storedata(file);
	
	fclose(file);
	exit(0);
	
	}
	int tep;
	printf("\n\t1) To Continue \t2) To Exit\n");
	scanf("%d",&tep);
	if(tep==1)
	{
	system("cls");
	user(&bank);
	}
	else
	{
	storedata(file);
	
	fclose(file);
	exit(0);
	}
}
void options(account* transaction)
{
	int n;
	system("cls");
	startnote();
	puts("\n\t\t1) DEPOSIT\n");
	puts("\t\t2) WITHDRAW \n");
	puts("\t\t3) Close Account\n");
	scanf("%d",&n);
	system("cls");
	startnote();
	switch(n)
	{
		case 1:
			int trans;
			printf("Enter Amount To Deposit\n ");
			scanf("%d",&trans);
			transaction->bal=transaction->bal+trans;
			printf("\n\tAvl. Balance= %d\n",transaction->bal);
			printf("Thank you for Banking with us\n");
			break;
		
		case 2:
			int debit;
			printf("Enter Amount To WITHDRAW	\n ");
			scanf("%d",&debit);
			if(transaction->bal>debit)
			{
				transaction->bal=transaction->bal-debit;
				printf("\n\tAvl. Balance= %d\n",transaction->bal);
				printf("Thank you for Banking with us\n");
			}
			else
			printf("SORRY !!! \nNot Sufficient money \n");
			break;
		case 3:
			printf("\tPLEASE | Conform Whether to Close account or not !!!\n It Will be permanently closed\n\t\t 1)YES\t2)NO\n");
			int n;
			scanf("%d",&n);
			system("cls");
			startnote();
			if(n==1)
			deletion(&bank,transaction->acc_no);
			break;
		default:
			printf("Wrong Choice\n");						
	}
}
void startingenterchoice()
{
	int p;
	puts("\n\t\t    press 1)TO ENTER       press 0)TO EXIT");
	
	scanf("%d",&p);
	system("cls");
	if(p!=1)
	{
	storedata(file);
	
	fclose(file);
	exit(0);
	}
	startnote();
}


/*********/
char* datas(account* data)
{
	char s[1000]="";
	char temp[50]=" ";
	if(data==NULL)
	return " ";
	else
	{
		sprintf(temp,"%d",data->acc_no);
		strcat(s,temp);
		strcat(s," ");
		sprintf(temp,"%d",data->pass);
		strcat(s,temp);
		strcat(s," ");
		sprintf(temp,"%d",data->bal);
		strcat(s,temp);
		strcat(s," ");
		strcat(s,data->name);
		strcat(s," ");	
		strcat(s,"\n");
	}
	char p[100]=" ";
	strcat(p,datas(data->next));
	strcat(s,p);
	
	return s;
}

void storedata(FILE* file)
{
	char all[10000]=" \n";
	strcpy(all,datas(bank));
	file=fopen("bankdata.txt","w");
	fputs(all,file);
	fclose(file);
}


void assign(account** add,int acc,int bal,int pass,char tnm[]);
struct account* filedatacopy(int acct,int bal,int pass,char s[]);



void readfile()
{
	int acc,bal,pass;
	char s1[20],s2[20],tnm[40]="";
	while(EOF != fscanf(file,"%d %d %d %s %s",&acc,&pass,&bal,s1,s2))
	{
		strcpy(tnm,s1);
		strcat(tnm," ");
		strcat(tnm,s2);
		no=acc;
	//	printf("%d %d %s %s %d\n",acc,bal,s1,s2,pass);
		assign(&bank,acc,bal,pass,tnm);
			
		
	}
}
void assign(account** add,int acc,int bal,int pass,char tnm[])
{
	if((*add)==NULL)
	{
		(*add)=filedatacopy(acc,bal,pass,tnm);
	}
	else
	{
		assign(&((*add)->next),acc,bal,pass,tnm);
	}
	
}

struct account* filedatacopy(int acct,int bal,int pass,char s[])
{
	account* acc=(account*)malloc(sizeof(struct account));
	acc->acc_no=acct;
	acc->bal=bal;
	strcpy(acc->name,s);
	acc->pass=pass;
	acc->next=NULL;
	
	return acc;
}






			/*main function*/
			


int main()
{
	//user experence enhancing 
	

	
	
	//***********************
	readfile();
	user(&bank);
	

	storedata(file);
	system("cls");
	fclose(file);
	printf("\n\t thank you visit again");
	return 0;
}
