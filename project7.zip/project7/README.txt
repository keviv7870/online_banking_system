this project 
/************************************/

WHEN RUNNING THE PROGRAM THIS PROGRAM :-

	
this program has in-built data storage in it - 
it contains some pre-defined data sets

what ever data will be provided by user will get stored
in it 

GIVING NEW DATA SHOULD BE IN FORMAT	

first name- should contain a single string only
second name- should contain a single string only
amount -only integer
password -only integer


this program is self repeating unless commond given to close


caution:-
giving wrong data or command can crash whole program
